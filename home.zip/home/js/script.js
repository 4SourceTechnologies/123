"use strick"
alert("hello");